﻿namespace BinaryKits.Zpl.Label
{
    /// <summary>
    /// Line Color
    /// </summary>
    public enum LineColor
    {
        /// <summary>
        /// Black
        /// </summary>
        Black,
        /// <summary>
        /// White
        /// </summary>
        White
    }
}
