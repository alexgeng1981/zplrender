﻿namespace BinaryKits.Zpl.Label.ImageConverters
{
    public class ImageResult
    {
        public string ZplData { get; set; }
        public int BinaryByteCount { get; set; }
        public int BytesPerRow { get; set; }
    }
}
